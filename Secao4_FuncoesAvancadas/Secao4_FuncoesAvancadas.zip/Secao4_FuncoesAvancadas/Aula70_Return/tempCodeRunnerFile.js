function soma(a, b) {
//     return a + b;
// }

// console.log(soma(5 , 2));

// function soma2(a, b)    {
//     console.log(a + b);
// }
// soma2(5 , 2);