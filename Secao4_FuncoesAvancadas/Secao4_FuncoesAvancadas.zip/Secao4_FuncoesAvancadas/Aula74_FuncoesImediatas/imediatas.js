// IIFE - Imediately Inoked Function Expression
// funções Imediatas

// Não queremos que nossas variaves se misturem com as variaveis do escopo global

// funcoes normais tocam o escopo global
// As IIFE não

